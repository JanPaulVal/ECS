<?php
$servername = @$_SERVER['SERVER_ADDR'];
$username = "root";
$password = "";

// check if database is online
$db_handle = @new mysqli( $GLOBALS['servername'], $GLOBALS['username'], $GLOBALS['password'], "ECS" );
if ($db_handle->connect_error)
{
	die("Database offline!");
}

function db_table_count($ecs_db_TABLE)
{
	$db_handle = @new mysqli( $GLOBALS['servername'], $GLOBALS['username'], $GLOBALS['password'], "ECS" );
	$db_query_result = $db_handle->query("SELECT * FROM " . $ecs_db_TABLE);
	mysqli_close($db_handle);
	return $db_query_result->num_rows;
}

function db_new_credential($ecs_db_USERNAME,$ecs_db_PASSWORD)
{
	$db_handle = @new mysqli( $GLOBALS['servername'], $GLOBALS['username'], $GLOBALS['password'], "ECS" );
	$db_query_result = $db_handle->query("INSERT INTO ecs_database_credential (Username, Password, Status)
VALUES ('" . $ecs_db_USERNAME . "', '" . $ecs_db_PASSWORD . "', 'Active')");
	mysqli_close($db_handle);
	if (TRUE === $db_query_result) 
	{
		$_SESSION["ecs_ERROR_MESSAGE"] = "New account has been created. Login to proceed.";
	} 
}

function db_login($ecs_db_USERNAME,$ecs_db_PASSWORD)
{
	$db_handle = @new mysqli( $GLOBALS['servername'], $GLOBALS['username'], $GLOBALS['password'], "ECS" );
	$db_query_result = $db_handle->query("SELECT * FROM ecs_database_credential WHERE Username = '" . $ecs_db_USERNAME . "' AND Password = '" . $ecs_db_PASSWORD . "'");
	mysqli_close($db_handle);
	
	if ( 0 < $db_query_result->num_rows)
	{
		$rowItem = $db_query_result->fetch_assoc();
		$_SESSION['ecs_LOGIN_ID'] = $rowItem['ID_credential'];
		echo '<script type="text/javascript">	window.location.href = "http://'. $GLOBALS['servername'] .'"; </script>';
	}
}

// Create database
// ===============================================
$db_handle = @new mysqli($servername, $username, $password, "ECS");
if ($db_handle->connect_error) 
{
	$db_handle = new mysqli($servername, $username, $password);
	$db_query = "CREATE DATABASE ECS";
	$db_handle->query($db_query);
	
	$db_handle = @new mysqli($servername, $username, $password, "ECS");
}

// Create credential
// ===============================================
$db_query_result = $db_handle->query("SELECT * FROM ecs_database_credential");
if ( FALSE === $db_query_result )
{
	$db_query = "CREATE TABLE ecs_database_credential (
	ID_credential INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	Username VARCHAR(30) NOT NULL,
	Password VARCHAR(50) NOT NULL,
	Status VARCHAR(25) NOT NULL,
	Creation_date TIMESTAMP
	)";
	$db_query_result = $db_handle->query($db_query);	
}

?>