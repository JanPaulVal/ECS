	<title>ECS - Login</title>
	<link href="./css/bootstrap.min.css" rel="stylesheet">
	<link href="./css/login.css" rel="stylesheet">
</head>
<?php
require __DIR__.'/database.php';

// Check if new account will be created
if ( @isset($_POST['ecs_input_NEW_ACCOUNT']) )
{
	db_new_credential($_POST['ecs_input_USERNAME'],$_POST['ecs_input_PASSWORD']);
}

// Login validation
if ( @isset($_POST['ecs_login']) )
{
	echo db_login($_POST['ecs_input_USERNAME'],$_POST['ecs_input_PASSWORD']);
}

// Check if no account was recorded
if ( 0 == db_table_count("ecs_database_credential") )
{
	$_SESSION["ecs_ERROR_MESSAGE"] = "System requires at least one account";
	echo $_SESSION["ecs_ERROR_MESSAGE"];
	$_SESSION["ecs_ERROR_MESSAGE"] = '';
	
	echo '
		<form method="Post">
			<br />Username <input type="text" name="ecs_input_USERNAME" />
			<br />Password <input type="password" name="ecs_input_PASSWORD" />
			<br /><input type="submit" name="ecs_input_NEW_ACCOUNT" value="Create account" />
		</form>
		';
}

// Default login
else
{
	if ( @isset($_SESSION["ecs_ERROR_MESSAGE"]) )
	{
		echo $_SESSION["ecs_ERROR_MESSAGE"];
		$_SESSION["ecs_ERROR_MESSAGE"] = '';
	}
	echo '
		<body class="text-center">
			<form class="form-signin" method="Post">
			
			<!--ToDo: Logo -->
			<img class="mb-4" src="../../assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
			
			<h1 class="h3 mb-3 font-weight-normal">Login</h1>
			
			<label for="inputEmail" class="sr-only">Username</label>
			<input name="ecs_input_USERNAME" type="text" id="inputEmail" class="form-control" placeholder="Username" required autofocus>
			
			<label for="inputPassword" class="sr-only">Password</label>
			<input name="ecs_input_PASSWORD" type="password" id="inputPassword" class="form-control" placeholder="Password" required>
			
			<div class="checkbox mb-3">
				<label>
				<input type="checkbox" value="remember-me"> Auto login on next access
				</label>
			</div>
			<button name="ecs_login" value="Login" class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
			<p class="mt-5 mb-3 text-muted">&copy; 2019</p>
			</form>
		';
}
?>