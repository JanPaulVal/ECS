<?php
$computerList = array("");
$subscriptionFileHandle = fopen("subscription_key", "r") or
	die("Site offline!");
while (($fileReadline = fgets($subscriptionFileHandle)) !== false) 
{
	array_push($computerList,$fileReadline);
}
fclose($subscriptionFileHandle);

if (!in_array( $_SERVER['REMOTE_ADDR'] , str_replace("\n", '', $computerList)))
{
	if ( @isset($_POST['subscription_key']) ) 
	{
		if ( 'subscription_key' == $_POST['subscription_key'] )
		{
			file_put_contents("subscription_key", "\n" . $_SERVER['REMOTE_ADDR'], FILE_APPEND | LOCK_EX);
			echo'
				<script>
				window.location.replace(window.location.href);
				</script>
				';
		}
	}
	echo'
		<form method="Post">
			Enter subscription key
			<input type="text" name="subscription_key" />
			<input type="submit" value="Activate" />
		</form>
		';
}
?>