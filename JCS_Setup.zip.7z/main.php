<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php
if ( ( !@isset($_SESSION['ecs_SECURITY_CHECK']) ) || 
     ( 'ecs_SECURITY_CHECK' != $_SESSION['ecs_SECURITY_CHECK'] ) )
{
	echo '
		<script type="text/javascript">
		window.location.href = "http://judiciary.gov.ph/";
		</script>
		';
}

// Verify logout
if ( @isset($_GET['logout']) )
{
	session_unset(); 
	session_destroy(); 
	echo '
		<script type="text/javascript">	window.location.href = "http://'. @$_SERVER['SERVER_ADDR'] .'"; </script>
	';
}

// Verify login 
if ( !@isset($_SESSION['ecs_LOGIN_ID']) )
{
	require './login.php';
}
else
{
	require './menu.php';
}
?>
</body></html>