<?php
if (!file_exists('security.php'))
{
	die("Site compromised!");
}
require __DIR__.'/security.php'; 

session_start();
$_SESSION["ecs_SECURITY_CHECK"] = "ecs_SECURITY_CHECK";
require __DIR__.'/main.php'; 
?>
