<?php
require __DIR__.'/database.php';

// Check if new account will be created
if ( @isset($_POST['ecs_input_NEW_ACCOUNT']) )
{
	db_new_credential($_POST['ecs_input_USERNAME'],$_POST['ecs_input_PASSWORD']);
}

// Login validation
if ( @isset($_POST['ecs_login']) )
{
	echo db_login($_POST['ecs_input_USERNAME'],$_POST['ecs_input_PASSWORD']);
}

// Check if no account was recorded
if ( 0 == db_table_count("ecs_database_credential") )
{
	//$_SESSION["ecs_ERROR_MESSAGE"] = "System requires at least one account";
	
	//echo '<h1 class="h3 mb-3 font-weight-normal">ECS - Admin Account</h1>';
	//echo $_SESSION["ecs_ERROR_MESSAGE"];
	//$_SESSION["ecs_ERROR_MESSAGE"] = '';
	
	echo '
	<form method="Post">
	<div class="card bg-light mb-3">
		<div class="card-header"><h1 class="h3 mb-3 font-weight-normal">Welcome to ECS</h1></div>
		<div class="card-body">
			<div class="card bg-light mb-3">
				<div class="card-header">Create 1st Admin Account</div>
				<div class="card-body">
						Username <input type="text" name="ecs_input_USERNAME" />
						<br />Password <input type="password" name="ecs_input_PASSWORD" />
				</div>
			</div>
			<div class="card bg-light mb-3">
				<div class="card-header">Admin Information</div>
				<div class="card-body">
					Firstname <input type="text" name="ecs_input_FIRSTNAME" />
					<br />Middlename <input type="password" name="ecs_input_MIDDLENAME" />
					<br />Lastname <input type="password" name="ecs_input_LASTNAME" />
				</div>
			</div>
			<div class="card bg-light mb-3">
				<div class="card-header">Contact Information</div>
				<div class="card-body">
					CP number<input type="text" name="ecs_input_CPNUMBER" />
					<br />Email address<input type="password" name="ecs_input_EMAILADDRESS" />
				</div>
			</div>
			By clicking "Create account", you are responsible for the accuracy of the information given above.
			<br /><input type="submit" name="ecs_input_NEW_ACCOUNT" value="Create account" />
		</div>
	</div>
	</form>
	';
}

// Default login
else
{
	if ( @isset($_SESSION["ecs_ERROR_MESSAGE"]) )
	{
		echo $_SESSION["ecs_ERROR_MESSAGE"];
		$_SESSION["ecs_ERROR_MESSAGE"] = '';
	}
	echo '
	<form method="Post">
	<div class="card bg-light mb-3">
		<div class="card-header"><h1 class="h3 mb-3 font-weight-normal">Welcome to ECS</h1></div>
		<div class="card-body">
			<div class="card bg-light mb-3">
				<div class="card-header">Login</div>
				<div class="card-body">
						Username <input type="text" name="ecs_input_USERNAME" />
						<br />Password <input type="password" name="ecs_input_PASSWORD" />
				</div>
			</div>
			<!--<div class="card bg-light mb-3">
				<div class="card-header">Admin Information</div>
				<div class="card-body">
					Firstname <input type="text" name="ecs_input_FIRSTNAME" />
					<br />Middlename <input type="password" name="ecs_input_MIDDLENAME" />
					<br />Lastname <input type="password" name="ecs_input_LASTNAME" />
				</div>
			</div>
			<div class="card bg-light mb-3">
				<div class="card-header">Contact Information</div>
				<div class="card-body">
					CP number<input type="text" name="ecs_input_CPNUMBER" />
					<br />Email address<input type="password" name="ecs_input_EMAILADDRESS" />
				</div>
			</div>
			By clicking "Create account", you are responsible for the accuracy of the information given above.
			<br /><input type="submit" name="ecs_input_NEW_ACCOUNT" value="Create account" />-->
			<button name="ecs_login" value="Login" class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
		</div>
	</div>
	</form>
	
	
	
		';
}
?>