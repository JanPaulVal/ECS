<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>ECS</title>
	<link href="./css/bootstrap.min.css" rel="stylesheet">
	<link href="./css/login.css" rel="stylesheet">
</head>
<body class="text-center">
	<script src="jquery/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="popper.js/popper.min.js"></script>
<?php

/*
if (!file_exists('security.php'))
{
	die("Site compromised!");
}
require __DIR__.'/security.php'; 
*/

session_start();
$_SESSION["ecs_SECURITY_CHECK"] = "ecs_SECURITY_CHECK";
if ( ( !@isset($_SESSION['ecs_SECURITY_CHECK']) ) || 
     ( 'ecs_SECURITY_CHECK' != $_SESSION['ecs_SECURITY_CHECK'] ) )
{
	echo '
		<script type="text/javascript">
		window.location.href = "http://judiciary.gov.ph/";
		</script>
		';
}

// Verify logout
if ( @isset($_GET['logout']) )
{
	session_unset(); 
	session_destroy(); 
	echo '
		<script type="text/javascript">	window.location.href = "http://'. @$_SERVER['SERVER_ADDR'] .'"; </script>
	';
}
?>

<div class="container h-100">
<section class="h-100">
  <header class="container h-100">
    <div class="d-flex align-items-center justify-content-center h-100">

	
	  <div class="d-flex flex-column">
        <!--<h1 class="text align-self-center p-2">.</h1>
        
        align starts here-->
      </div>
<?php
// Verify login 
if ( !@isset($_SESSION['ecs_LOGIN_ID']) )
{
	require './login.php';
}
else
{
	require './menu.php';
	require './body.php';
}
?>
    </div>
  </header>
</section>

</body></html>