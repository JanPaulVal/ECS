
	
	<div class="container">
	<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
	<a class="navbar-brand" href="">ECS</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
	
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
	<ul class="navbar-nav mr-auto">
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Petition</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="?Petition=FilePetition">File a petition</a>
				<a class="dropdown-item" href="?Petition=ViewPetition">View filled petitions</a>
				<a class="dropdown-item" href="?Petition=UpdatePetition">Update petitions</a>
			</div>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Calendar</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="?Calendar=AddCourtSchedule">Set a court schedule</a>
				<a class="dropdown-item" href="?Calendar=ViewCourtSchedule">View court schedules</a>
				<a class="dropdown-item" href="?Calendar=UpdateCourtSchedule">Update schedules information</a>
			</div>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Payments</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="?Payments=RecordNewPayment">Record new payment</a>
				<a class="dropdown-item" href="?Payments=ViewPayments">View payments</a>
				<a class="dropdown-item" href="?Payments=UpdatePayment">Update payments information</a>
			</div>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Court Order</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="?CourtOrder=RecordNewCourtOrder">New court order</a>
				<a class="dropdown-item" href="?CourtOrder=ViewCourtOrder">View court orders</a>
				<a class="dropdown-item" href="?CourtOrder=UpdateCourtOrder">Update court order status</a>
			</div>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Jurisprudence</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="?Jurisprudence=PublishJurisprudence">Publish court decision</a>
				<a class="dropdown-item" href="?Jurisprudence=ViewJurisprudence">View court decisions</a>
				<a class="dropdown-item" href="?Jurisprudence=UpdateJurisprudence">Limit access to court decisions</a>
			</div>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin Functions</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="?Admin=ActivateAccounts">Activate pending new accounts</a>
				<a class="dropdown-item" href="?Admin=UpdateAccounts">Limit account access</a>
				<a class="dropdown-item" href="?Admin=UpdateAccountInfo">Update account information</a>
			</div>
		</li>
	</ul>
	<form class="form-inline my-2 my-lg-0" action="?Search" method="POST">
		<input class="form-control mr-sm-2" type="Search" placeholder="ECS Search" aria-label="Search ECS">
		<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
	</form>
		Dela Cruz, Juan
		<a class="nav-link" href="?logout">Log Out</a>
	</div>
	</nav>
	</div>
