<div class="container h-100">
<section class="h-100">
  <header class="container h-100">
    <div class="d-flex align-items-center justify-content-center h-100">

	
	  <div class="d-flex flex-column">
        <h1 class="text align-self-center p-2">.</h1>
        
        align starts here
      </div>
<?php

?>
    </div>
  </header>
</section>